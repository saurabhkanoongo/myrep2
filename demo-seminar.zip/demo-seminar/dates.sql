BEGIN
    p.l(dt.val ('1/1'));
    p.l(dt.val ('6/1996'));
    p.l(dt.val ('12-APR-09'));
    p.l(dt.val ('19991205'));
    p.l(dt.val ('1/1/1'));
END;
/ 
