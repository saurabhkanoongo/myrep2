delete from employee2;
commit;
