SELECT column_name, comments
  FROM all_col_comments
 WHERE table_name = 'ALL_ARGUMENTS'