BEGIN
   delete from dmr_table;
   
   INSERT INTO dmr_table
        VALUES (1);

   INSERT INTO dmr_table
        VALUES (2);

   INSERT INTO dmr_table
        VALUES (3);

   INSERT INTO dmr_table
        VALUES (4);

   INSERT INTO dmr_table
        VALUES (5);
END;