DECLARE
   l1   VARCHAR2 (500);
   l2   VARCHAR2 (5000);
   l3   VARCHAR2 (32767);
BEGIN
   l1 := 'abc';
   l2 := 'abc';
   l3 := 'abc';
END;