CREATE OR REPLACE DIRECTORY demo AS 'c:\work\demo-seminar'
/
CREATE OR REPLACE DIRECTORY temp AS 'c:\temp'
/