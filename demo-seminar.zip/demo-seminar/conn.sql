REM Connect as scott/tiger (done as script to easily change later)

CONNECT SCOTT/TIGER
@login
